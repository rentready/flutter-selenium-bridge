import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Web App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String name = '';
  String multilineText = '';
  String multilineButtonText = '';
  String greeting = '';
  String reveledPassword = '';
  String clickMessage = '';
  String password = '';
  bool _isPasswordVisible = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('App Main Screen'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const Text('App Main Screen'),
             Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                maxLines: 2,
                onChanged: (text) {
                  setState(() {
                    multilineText = text;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Multiline text field',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  multilineButtonText = 'You entered, $multilineText';
                });
              },
              child: Text(multilineButtonText.isEmpty ? 'Check what entered' : multilineButtonText),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                onChanged: (text) {
                  setState(() {
                    name = text;
                  });
                },
                decoration: const InputDecoration(
                  labelText: 'Your name',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  greeting = 'Hello, $name';
                });
              },
              child: Text(greeting.isEmpty ? 'Say Hi' : greeting),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Semantics(
                identifier: 'password_field',
                label: "My password field",
                child: TextFormField(
                  onChanged: (text) {
                    setState(() {
                      password = text;
                    });
                  },
                  obscureText:
                      !_isPasswordVisible, // Use the boolean to control visibility
                  decoration: InputDecoration(
                    labelText: 'Password',
                    hintText: 'Enter your password',
                    // Add an icon button inside the password field as a suffix icon
                    suffixIcon: IconButton(
                      icon: Icon(
                        // Change the icon based on the password visibility
                        _isPasswordVisible
                            ? Icons.visibility_off
                            : Icons.visibility,
                      ),
                      onPressed: () {
                        // Update the password visibility state
                        setState(() {
                          _isPasswordVisible = !_isPasswordVisible;
                        });
                      },
                    ),
                  ),
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  reveledPassword = 'Password: $password';
                });
              },
              child: Text(reveledPassword.isEmpty ? 'Say Password' : reveledPassword),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  clickMessage = 'You clicked me';
                });
              },
              child: Text(clickMessage.isEmpty ? 'Click Me' : clickMessage),
            ),
          ],
        ),
      ),
    );
  }
}