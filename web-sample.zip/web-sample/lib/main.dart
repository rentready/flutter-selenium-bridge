import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Web App',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const MainScreen(),
    );
  }
}

class MainScreen extends StatefulWidget {
  const MainScreen({super.key});

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  String name = '';
  String greeting = '';
  String clickMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('App Main Screen'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text('App Main Screen'),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: TextField(
                onChanged: (text) {
                  setState(() {
                    name = text;
                  });
                },
                decoration: InputDecoration(
                  labelText: 'Your name',
                ),
              ),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  greeting = 'Hello, $name';
                });
              },
              child: Text(greeting.isEmpty ? 'Say Hi' : greeting),
            ),
            ElevatedButton(
              onPressed: () {
                setState(() {
                  clickMessage = 'You clicked me';
                });
              },
              child: Text(clickMessage.isEmpty ? 'Click Me' : clickMessage),
            ),
          ],
        ),
      ),
    );
  }
}